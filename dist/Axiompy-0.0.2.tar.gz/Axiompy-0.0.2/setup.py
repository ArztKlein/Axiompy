from distutils.core import setup

setup(name='Axiompy',
      version='0.0.2',
      description='Unit Conversions and other math',
      author='ArztKlein',
      url='https://www.python.org/sigs/distutils-sig/',
      keywords=['python','unit conversion', 'units']
     )